/**
 * ============================================================
 * 记账本 - 后端服务器 (server.js)
 * ------------------------------------------------------------
 * 技术栈：Node.js 原生 http 模块 + MySQL (mysql2)
 * 功能概述：
 *   1. 静态文件服务（页面 / 样式 / 前端脚本）
 *   2. 用户注册 / 登录 / 退出（密码 scrypt 加盐哈希，令牌会话存数据库）
 *   3. 记账记录接口：列表 / 新增 / 编辑 / 删除（部分字段更新）
 *   4. 统计接口：月度收支汇总、近 N 天支出（柱状图数据）
 *   5. 分类接口：列表 / 新增 / 编辑（含历史记录同步）/ 删除（有记录不可删）
 *   6. 数据隔离：所有数据按登录用户的 user_id 过滤，互不可见
 * 安全措施：参数化 SQL（防注入）、输入校验、路径穿越防护、仅允许本机 CORS
 * ============================================================
 */

/** Node 内置模块：创建 HTTP 服务器 */
const http = require("http");
/** Node 内置模块：读取静态文件 */
const fs2 = require("fs");
/** Node 内置模块：路径处理 */
const path = require("path");
/** Node 内置模块：解析请求 URL */
const { URL } = require("url");
/** Node 内置模块：密码哈希 / 随机令牌生成 */
const crypto = require("crypto");
/** MySQL 数据库驱动（Promise 版本） */
const mysql = require("mysql2/promise");

/** 服务器监听端口 */
const PORT = 8080;

/**
 * 数据库连接配置（可通过环境变量覆盖，默认连接本机 MySQL 的 app 库）
 * dateStrings:true 让日期字段直接以 "YYYY-MM-DD" 字符串返回，避免时区/格式问题
 */
const DB = {
  host: process.env.DB_HOST || "localhost",
  port: parseInt(process.env.DB_PORT || "3306"),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "app",
  dateStrings: true
};

/** 数据库连接池（全局使用） */
var pool;

/**
 * 默认分类列表（[名称, 类型] 成对排列），新用户注册时自动为其插入一套
 */
const DEFAULT_CATEGORIES = ["餐饮","expense","交通","expense","购物","expense","娱乐","expense","住房","expense","日用","expense","医疗","expense","工资","income","奖金","income","其他收入","income","其他支出","expense"];

/**
 * 兼容旧数据库：如果指定表缺少某列则自动补充（用于给已有表添加 user_id 列）
 * @param {string} table 表名
 * @param {string} column 列名
 * @param {string} ddl 建列语句
 */
async function ensureColumn(table, column, ddl) {
  var r = await pool.query("SELECT COUNT(*) as c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=? AND TABLE_NAME=? AND COLUMN_NAME=?", [DB.database, table, column]);
  if (r[0][0].c === 0) await pool.query("ALTER TABLE " + table + " ADD COLUMN " + ddl);
}

/**
 * 初始化数据库：建库、建表（不存在才创建）、为旧表补充新列
 */
async function initDB() {
  /** 先建立不指定库的连接，用于创建数据库 */
  var conn = await mysql.createConnection({
    host: DB.host, port: DB.port,
    user: DB.user, password: DB.password
  });
  await conn.query("CREATE DATABASE IF NOT EXISTS `" + DB.database + "` CHARACTER SET utf8mb4");
  await conn.end();

  /** 建立连接池，并创建四张表 */
  pool = mysql.createPool(DB);
  /** 用户表：id、用户名（唯一）、密码哈希、注册时间 */
  await pool.query("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(8) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  /** 会话表：登录令牌 -> 用户 id（服务器重启后登录状态仍有效） */
  await pool.query("CREATE TABLE IF NOT EXISTS sessions (token VARCHAR(64) PRIMARY KEY, user_id INT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_user (user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  /** 分类表：名称、类型、是否默认、所属用户 */
  await pool.query("CREATE TABLE IF NOT EXISTS categories (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50) NOT NULL, type ENUM('income','expense') NOT NULL, is_default TINYINT(1) DEFAULT 0, user_id INT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  /** 记账记录表：日期、金额、分类、类型、备注、状态、所属用户 */
  await pool.query("CREATE TABLE IF NOT EXISTS transactions (id INT AUTO_INCREMENT PRIMARY KEY, date DATE NOT NULL, amount DECIMAL(10,2) NOT NULL, category VARCHAR(50) NOT NULL, type ENUM('income','expense') NOT NULL, note TEXT, status ENUM('pending','done') DEFAULT 'done', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, user_id INT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  /** 老版本建的表没有 user_id 列，这里自动补齐（实现多用户数据隔离） */
  await ensureColumn("transactions", "user_id", "user_id INT NULL");
  await ensureColumn("categories", "user_id", "user_id INT NULL");
  console.log("MySQL database ready");
}

/**
 * 统一 JSON 响应：写出响应头并以 JSON 返回数据
 * @param {http.ServerResponse} res 响应对象
 * @param {object} data 返回的数据
 * @param {number} [status] HTTP 状态码，默认 200
 */
function sendJson(res, data, status) {
  res.writeHead(status || 200, {"Content-Type":"application/json; charset=utf-8"});
  res.end(JSON.stringify(data));
}

/** 静态文件类型映射表 */
var MIME = {".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"application/javascript; charset=utf-8",".ico":"image/x-icon",".svg":"image/svg+xml",".png":"image/png",".jpg":"image/jpeg",".txt":"text/plain; charset=utf-8"};

/**
 * 静态文件服务：返回页面/样式/脚本等文件
 * 安全防护：路径归一化后必须位于应用目录内，否则返回 403（防路径穿越）
 * 响应头加 Cache-Control:no-cache，保证浏览器总是拿到最新文件
 * @param {http.ServerResponse} res 响应对象
 * @param {string} p 请求路径
 */
function serveStatic(res, p) {
  /** 先解码 URL（防止 %2e%2e 等编码绕过） */
  var decoded;
  try { decoded = decodeURIComponent(p); } catch(e) { decoded = p; }
  var f = path.normalize(path.join(__dirname, decoded === "/" ? "index.html" : decoded));
  var root = path.normalize(__dirname);
  /** 目录边界检查：解析后的路径必须在应用目录内 */
  if (f !== root && f.indexOf(root + path.sep) !== 0) {
    res.writeHead(403); res.end("Forbidden");
    return;
  }
  var ext = path.extname(f);
  try {
    var content = fs2.readFileSync(f);
    res.writeHead(200, {"Content-Type": MIME[ext] || "application/octet-stream", "Cache-Control": "no-cache"});
    res.end(content);
  } catch(e) {
    res.writeHead(404); res.end("Not Found");
  }
}

// ============================================================
// 输入校验与密码工具函数
// ============================================================

/**
 * 校验日期字符串是否为真实存在的 "YYYY-MM-DD" 日期
 * （如 2026-02-30 会被拒绝）
 * @param {*} s 待校验的值
 * @returns {boolean} 是否合法
 */
function validDate(s) {
  if (typeof s !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  var d = new Date(s + "T00:00:00");
  return !isNaN(d.getTime()) &&
    d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0") === s;
}

/** 校验金额：必须是 >= 0 的有限数字（拒绝负数、NaN、字符串），且不超过 DECIMAL(10,2) 上限 99999999.99 */
function validAmount(v) { return typeof v === "number" && isFinite(v) && v >= 0 && v <= 99999999.99; }

/** 校验记录类型：只能是收入或支出 */
function validType(t) { return t === "income" || t === "expense"; }

/** 校验状态：只能是已完成或未完成 */
function validStatus(s) { return s === "done" || s === "pending"; }

/**
 * 校验用户名：去掉首尾空格后长度 2-8 个字符，且不含控制字符
 * @param {*} u 待校验的用户名
 * @returns {boolean} 是否合法
 */
function validUsername(u) {
  if (typeof u !== "string") return false;
  u = u.trim();
  return u.length >= 2 && u.length <= 8 && !/[\x00-\x1f\x7f]/.test(u);
}

/** 校验密码：长度 6-18 位 */
function validPassword(p) {
  return typeof p === "string" && p.length >= 6 && p.length <= 18;
}

/**
 * 密码加密：生成随机盐 + scrypt 派生 64 字节哈希，以 "盐:哈希" 格式存储
 * @param {string} pw 明文密码
 * @returns {string} 加盐哈希字符串
 */
function hashPassword(pw) {
  var salt = crypto.randomBytes(16).toString("hex");
  return salt + ":" + crypto.scryptSync(pw, salt, 64).toString("hex");
}

/**
 * 密码校验：用存储的盐重新派生哈希，并与存储值常量时间比较（防时序攻击）
 * @param {string} pw 明文密码
 * @param {string} stored 数据库中的 "盐:哈希"
 * @returns {boolean} 是否匹配
 */
function verifyPassword(pw, stored) {
  var parts = String(stored || "").split(":");
  if (parts.length !== 2) return false;
  try {
    var h = crypto.scryptSync(pw, parts[0], 64);
    var expected = Buffer.from(parts[1], "hex");
    return h.length === expected.length && crypto.timingSafeEqual(h, expected);
  } catch(e) { return false; }
}

/**
 * 主请求处理器：解析 URL 与方法，按路由分发处理
 * @param {http.IncomingMessage} req 请求对象
 * @param {http.ServerResponse} res 响应对象
 */
async function handleRequest(req, res) {
  /** 用 WHATWG URL 解析（url.parse 已废弃），相对地址补上占位主机 */
  var u = new URL(req.url, "http://localhost");
  var pn = u.pathname;
  var method = req.method;

  /** CORS：只允许本机(localhost/127.0.0.1)来源跨域，防止外部网页调用本地接口 */
  var origin = req.headers.origin;
  if (origin && /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  }
  /** 预检请求直接放行 */
  if (method === "OPTIONS") { res.writeHead(204); res.end(); return; }

  try {
    /** 打印接口请求日志（便于排查问题） */
    if (pn.indexOf("/api/") === 0) console.log("API req:", method, pn);

    /** 读取并解析 POST / PUT 的 JSON 请求体（限制最大 1MB，防止超大请求耗尽内存） */
    var body = null;
    if (method === "POST" || method === "PUT") {
      var chunks = [];
      var total = 0, tooLarge = false;
      await new Promise(function(resolve) {
        req.on("data", function(c) {
          total += c.length;
          /** 超限后不再累积数据（避免内存被耗尽），但继续排空请求流以便正常返回 413 响应 */
          if (total > 1024 * 1024) { tooLarge = true; return; }
          chunks.push(c);
        });
        req.on("end", function() { resolve(); });
        req.on("error", function() { resolve(); });
      });
      if (tooLarge) return sendJson(res, {error:"\u8bf7\u6c42\u4f53\u8fc7\u5927"}, 413);
      try { body = JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch(e) {}
    }

    // ----------------------------------------------------------
    // 注册接口（公开，无需登录）：
    // 校验用户名/密码 -> 查重 -> 写入用户表 -> 第一个用户接管旧数据
    // -> 为新用户插入默认分类 -> 建立会话 -> 返回令牌（自动登录）
    // ----------------------------------------------------------
    if (pn === "/api/register" && method === "POST") {
      var rname = body ? body.username : undefined;
      var rpw = body ? body.password : undefined;
      if (!validUsername(rname)) return sendJson(res, {error:"\u7528\u6237\u540d\u957f\u5ea6\u9700\u4e3a2-8\u4e2a\u5b57\u7b26"}, 400);
      if (!validPassword(rpw)) return sendJson(res, {error:"\u5bc6\u7801\u957f\u5ea6\u9700\u4e3a6-18\u4f4d"}, 400);
      var uname = rname.trim();
      /** 查重：用户名已存在则拒绝 */
      var dup = await pool.query("SELECT id FROM users WHERE username=?", [uname]);
      if (dup[0].length > 0) return sendJson(res, {error:"\u7528\u6237\u540d\u5df2\u5b58\u5728"}, 409);
      /** 判断是否为第一个用户（决定是否接管无主的旧数据） */
      var isFirst = (await pool.query("SELECT COUNT(*) as c FROM users"))[0][0].c === 0;
      /** 写入新用户（密码存加盐哈希）；并发注册撞唯一约束时按已存在处理 */
      var ir;
      try {
        ir = await pool.query("INSERT INTO users (username,password_hash) VALUES (?,?)", [uname, hashPassword(rpw)]);
      } catch(e) {
        if (e && e.code === "ER_DUP_ENTRY") return sendJson(res, {error:"\u7528\u6237\u540d\u5df2\u5b58\u5728"}, 409);
        throw e;
      }
      var uid = ir[0].insertId;
      /** 第一个注册的用户自动接管之前无登录状态下的历史数据 */
      if (isFirst) {
        await pool.query("UPDATE transactions SET user_id=? WHERE user_id IS NULL", [uid]);
        await pool.query("UPDATE categories SET user_id=? WHERE user_id IS NULL", [uid]);
      }
      /** 若该用户还没有分类，则为它插入一套默认分类 */
      var cc = await pool.query("SELECT COUNT(*) as c FROM categories WHERE user_id=?", [uid]);
      if (cc[0][0].c === 0) {
        for (var i = 0; i < DEFAULT_CATEGORIES.length; i += 2) {
          await pool.query("INSERT INTO categories (name,type,is_default,user_id) VALUES (?,?,1,?)", [DEFAULT_CATEGORIES[i], DEFAULT_CATEGORIES[i+1], uid]);
        }
      }
      /** 生成随机令牌并写入会话表 */
      var token = crypto.randomBytes(32).toString("hex");
      await pool.query("INSERT INTO sessions (token,user_id) VALUES (?,?)", [token, uid]);
      console.log("REGISTER ok:", uname, "uid:", uid);
      return sendJson(res, {token:token, username:uname}, 201);
    }

    // ----------------------------------------------------------
    // 登录接口（公开）：校验用户名密码 -> 建立会话 -> 返回令牌
    // ----------------------------------------------------------
    if (pn === "/api/login" && method === "POST") {
      var lname = body ? body.username : undefined;
      var lpw = body ? body.password : undefined;
      if (typeof lname !== "string" || typeof lpw !== "string") return sendJson(res, {error:"\u7528\u6237\u540d\u6216\u5bc6\u7801\u9519\u8bef"}, 401);
      var lr = await pool.query("SELECT * FROM users WHERE username=?", [lname.trim()]);
      /** 用户不存在或密码错误时统一提示，避免暴露账号是否存在 */
      if (lr[0].length === 0 || !verifyPassword(lpw, lr[0][0].password_hash)) {
        return sendJson(res, {error:"\u7528\u6237\u540d\u6216\u5bc6\u7801\u9519\u8bef"}, 401);
      }
      var token = crypto.randomBytes(32).toString("hex");
      await pool.query("INSERT INTO sessions (token,user_id) VALUES (?,?)", [token, lr[0][0].id]);
      return sendJson(res, {token:token, username:lr[0][0].username});
    }

    // ----------------------------------------------------------
    // 登录拦截（Auth gate）：除注册/登录外，所有 /api/* 接口都必须携带有效令牌
    // ----------------------------------------------------------
    var user = null, authToken = null;
    if (pn.indexOf("/api/") === 0 && pn !== "/api/register" && pn !== "/api/login") {
      /** 从 Authorization: Bearer xxx 头中提取令牌 */
      var ah = req.headers.authorization || "";
      var am = ah.match(/^Bearer\s+(.+)$/i);
      if (!am) { console.log("AUTH 401 (no token):", method, pn); return sendJson(res, {error:"\u672a\u767b\u5f55"}, 401); }
      authToken = am[1];
      /** 用令牌关联出用户信息（会话表 join 用户表），超过 30 天的会话视为过期 */
      var ur = await pool.query("SELECT s.user_id, u.username FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)", [authToken]);
      if (ur[0].length === 0) {
        /** 过期/失效令牌顺手清理掉，避免会话表无限膨胀 */
        await pool.query("DELETE FROM sessions WHERE token=?", [authToken]).catch(function() {});
        console.log("AUTH 401 (bad/expired token):", method, pn);
        return sendJson(res, {error:"\u767b\u5f55\u5df2\u8fc7\u671f\uff0c\u8bf7\u91cd\u65b0\u767b\u5f55"}, 401);
      }
      user = ur[0][0];
    }

    /** 退出登录：删除当前会话 */
    if (pn === "/api/logout" && method === "POST") {
      await pool.query("DELETE FROM sessions WHERE token=?", [authToken]);
      return sendJson(res, {ok:true});
    }

    /** 获取当前登录用户信息 */
    if (pn === "/api/me" && method === "GET") {
      return sendJson(res, {id:user.user_id, username:user.username});
    }

    // ============================================================
    // 记账记录接口（全部按 user_id 隔离）
    // ============================================================

    /** 查询某年某月的记账记录（按日期倒序） */
    if (pn === "/api/transactions" && method === "GET") {
      var year = u.searchParams.get("year") || new Date().getFullYear().toString();
      var month = u.searchParams.get("month") || (new Date().getMonth() + 1).toString().padStart(2, "0");
      var r = await pool.query("SELECT * FROM transactions WHERE user_id=? AND DATE_FORMAT(date,'%Y') = ? AND DATE_FORMAT(date,'%m') = ? ORDER BY date DESC, id DESC", [user.user_id, year, month]);
      return sendJson(res, r[0]);
    }

    /** 新增记账记录（校验字段后写入，带 user_id） */
    if (pn === "/api/transactions" && method === "POST") {
      if (!body || !validDate(body.date) || !validAmount(body.amount)) return sendJson(res, {error:"\u8bf7\u6c42\u53c2\u6570\u65e0\u6548\uff08\u65e5\u671f\u683c\u5f0f\u6216\u91d1\u989d\u4e0d\u6b63\u786e\uff09"}, 400);
      var tType = body.type === undefined ? "expense" : body.type;
      var tStatus = body.status === undefined ? "done" : body.status;
      var tCat = (body.category === undefined || body.category === null) ? "" : body.category.toString().trim();
      var tNote = (body.note === undefined || body.note === null) ? "" : String(body.note);
      if (!validType(tType)) return sendJson(res, {error:"\u7c7b\u578b\u65e0\u6548"}, 400);
      if (!validStatus(tStatus)) return sendJson(res, {error:"\u72b6\u6001\u65e0\u6548"}, 400);
      if (!tCat) return sendJson(res, {error:"\u5206\u7c7b\u4e0d\u80fd\u4e3a\u7a7a"}, 400);
      if (tCat.length > 50) return sendJson(res, {error:"\u5206\u7c7b\u540d\u8fc7\u957f"}, 400);
      var r = await pool.query("INSERT INTO transactions (date,amount,category,type,note,status,user_id) VALUES (?,?,?,?,?,?,?)",
        [body.date, body.amount, tCat, tType, tNote, tStatus, user.user_id]);
      body.id = r[0].insertId;
      return sendJson(res, body, 201);
    }

    /** 按 id 定位单条记录（用于编辑 / 删除） */
    var tm = pn.match(/^\/api\/transactions\/(\d+)$/);
    if (tm) {
      var id = parseInt(tm[1]);

      /** 编辑记录：支持部分字段更新（只更新请求中携带的字段），并限制只能改自己的记录 */
      if (method === "PUT") {
        if (!body) return sendJson(res, {error:"\u8bf7\u6c42\u4f53\u4e0d\u80fd\u4e3a\u7a7a"}, 400);
        var exist = await pool.query("SELECT id FROM transactions WHERE id=? AND user_id=?", [id, user.user_id]);
        if (exist[0].length === 0) return sendJson(res, {error:"\u8bb0\u5f55\u672a\u627e\u5230"}, 404);
        var sets = [], vals = [];
        if (body.date !== undefined) {
          if (!validDate(body.date)) return sendJson(res, {error:"\u65e5\u671f\u683c\u5f0f\u65e0\u6548"}, 400);
          sets.push("date=?"); vals.push(body.date);
        }
        if (body.amount !== undefined) {
          if (!validAmount(body.amount)) return sendJson(res, {error:"\u91d1\u989d\u65e0\u6548"}, 400);
          sets.push("amount=?"); vals.push(body.amount);
        }
        if (body.category !== undefined) {
          var uc = body.category.toString().trim();
          if (uc.length > 50) return sendJson(res, {error:"\u5206\u7c7b\u540d\u8fc7\u957f"}, 400);
          sets.push("category=?"); vals.push(uc);
        }
        if (body.type !== undefined) {
          if (!validType(body.type)) return sendJson(res, {error:"\u7c7b\u578b\u65e0\u6548"}, 400);
          sets.push("type=?"); vals.push(body.type);
        }
        if (body.note !== undefined) { sets.push("note=?"); vals.push(body.note === null ? "" : String(body.note)); }
        if (body.status !== undefined) {
          if (!validStatus(body.status)) return sendJson(res, {error:"\u72b6\u6001\u65e0\u6548"}, 400);
          sets.push("status=?"); vals.push(body.status);
        }
        if (sets.length === 0) return sendJson(res, {ok:true});
        vals.push(id, user.user_id);
        await pool.query("UPDATE transactions SET " + sets.join(",") + " WHERE id=? AND user_id=?", vals);
        return sendJson(res, {ok:true});
      }

      /** 删除记录：只允许删除自己的记录，不存在则返回 404 */
      if (method === "DELETE") {
        var dr = await pool.query("DELETE FROM transactions WHERE id=? AND user_id=?", [id, user.user_id]);
        if (dr[0].affectedRows === 0) return sendJson(res, {error:"\u8bb0\u5f55\u672a\u627e\u5230"}, 404);
        return sendJson(res, {ok:true});
      }
    }

    // ============================================================
    // 统计接口
    // ============================================================

    /** 月度收支统计：按类型分组求和，返回收入/支出/结余 */
    if (pn === "/api/transactions/stats" && method === "GET") {
      var y = u.searchParams.get("year") || new Date().getFullYear().toString();
      var m = u.searchParams.get("month") || (new Date().getMonth() + 1).toString().padStart(2, "0");
      var r = await pool.query("SELECT type, SUM(amount) as total FROM transactions WHERE user_id=? AND DATE_FORMAT(date,'%Y')=? AND DATE_FORMAT(date,'%m')=? GROUP BY type", [user.user_id, y, m]);
      var income = 0, expense = 0;
      r[0].forEach(function(row) { if (row.type === "income") income = parseFloat(row.total); else expense = parseFloat(row.total); });
      return sendJson(res, {year:y, month:m, income:income, expense:expense, balance:income - expense});
    }

    /** 近 N 天每日支出（柱状图数据）：起始日期由服务器本地时间计算，避免与 MySQL CURDATE() 时区不一致而错位一天 */
    if (pn === "/api/transactions/expenses" && method === "GET") {
      var days = parseInt(u.searchParams.get("days") || "7", 10);
      if (isNaN(days) || days < 1) days = 7;
      if (days > 90) days = 90;
      var start = new Date(); start.setDate(start.getDate() - (days - 1));
      var sy = start.getFullYear(), sm = start.getMonth() + 1, sd = start.getDate();
      var startStr = sy + '-' + (sm < 10 ? '0' + sm : sm) + '-' + (sd < 10 ? '0' + sd : sd);
      var r = await pool.query("SELECT date, SUM(amount) as amount FROM transactions WHERE type='expense' AND user_id=? AND date >= ? GROUP BY date ORDER BY date", [user.user_id, startStr]);
      var map = {}; r[0].forEach(function(row) { map[row.date] = parseFloat(row.amount); });
      var result = [];
      /** 从今天往前推 days 天，逐日生成日期键（用本地时间，避免 UTC 差一天） */
      for (var i = days - 1; i >= 0; i--) {
        var d = new Date(); d.setDate(d.getDate() - i);
        var mm = d.getMonth() + 1, dd = d.getDate();
        var key = d.getFullYear() + '-' + (mm < 10 ? '0' + mm : mm) + '-' + (dd < 10 ? '0' + dd : dd);
        result.push({date: key, amount: map[key] || 0});
      }
      return sendJson(res, result);
    }

    // ============================================================
    // 分类接口（全部按 user_id 隔离）
    // ============================================================

    /** 查询当前用户的全部分类 */
    if (pn === "/api/categories" && method === "GET") {
      var r = await pool.query("SELECT * FROM categories WHERE user_id=? ORDER BY id", [user.user_id]);
      return sendJson(res, r[0]);
    }

    /** 新增分类：校验名称长度/类型、查重后写入（属于当前用户） */
    if (pn === "/api/categories" && method === "POST") {
      if (!body || !body.name || !body.name.toString().trim()) return sendJson(res, {error:"\u7f3a\u5c11\u5206\u7c7b\u540d\u79f0"}, 400);
      var cName = body.name.toString().trim();
      if (cName.length > 50) return sendJson(res, {error:"\u5206\u7c7b\u540d\u8fc7\u957f"}, 400);
      var cType = body.type === undefined ? "expense" : body.type;
      if (!validType(cType)) return sendJson(res, {error:"\u7c7b\u578b\u65e0\u6548"}, 400);
      /** 同名（同类型）分类查重 */
      var dup = await pool.query("SELECT id FROM categories WHERE name=? AND type=? AND user_id=?", [cName, cType, user.user_id]);
      if (dup[0].length > 0) return sendJson(res, {error:"\u540c\u540d\u5206\u7c7b\u5df2\u5b58\u5728"}, 400);
      var r = await pool.query("INSERT INTO categories (name,type,user_id) VALUES (?,?,?)", [cName, cType, user.user_id]);
      return sendJson(res, {id:r[0].insertId, name:cName, type:cType, is_default:0}, 201);
    }

    /** 按 id 定位单个分类（用于编辑 / 删除） */
    var cm = pn.match(/^\/api\/categories\/(\d+)$/);
    if (cm) {
      var cid = parseInt(cm[1]);

      /** 编辑分类：默认分类不可编辑；改名/改类型时同步更新历史记账记录的分类名 */
      if (method === "PUT") {
        var cr = await pool.query("SELECT * FROM categories WHERE id=? AND user_id=?", [cid, user.user_id]);
        if (cr[0].length === 0) return sendJson(res, {error:"\u5206\u7c7b\u672a\u627e\u5230"}, 404);
        if (cr[0][0].is_default) return sendJson(res, {error:"\u7cfb\u7edf\u9ed8\u8ba4\u5206\u7c7b\u4e0d\u53ef\u7f16\u8f91"}, 400);
        if (!body || !body.name || !body.name.toString().trim()) return sendJson(res, {error:"\u7f3a\u5c11\u5206\u7c7b\u540d\u79f0"}, 400);
        var cn = body.name.toString().trim();
        if (cn.length > 50) return sendJson(res, {error:"\u5206\u7c7b\u540d\u8fc7\u957f"}, 400);
        var ct = body.type === undefined ? cr[0][0].type : body.type;
        if (!validType(ct)) return sendJson(res, {error:"\u7c7b\u578b\u65e0\u6548"}, 400);
        var dup = await pool.query("SELECT id FROM categories WHERE name=? AND type=? AND user_id=? AND id<>?", [cn, ct, user.user_id, cid]);
        if (dup[0].length > 0) return sendJson(res, {error:"\u540c\u540d\u5206\u7c7b\u5df2\u5b58\u5728"}, 400);
        var oldName = cr[0][0].name, oldType = cr[0][0].type;
        await pool.query("UPDATE categories SET name=?,type=? WHERE id=? AND user_id=?", [cn, ct, cid, user.user_id]);
        /** 分类名或类型变化时，把历史记录里的旧分类名同步为新名 */
        if (oldName !== cn || oldType !== ct) {
          await pool.query("UPDATE transactions SET category=? WHERE category=? AND type=? AND user_id=?", [cn, oldName, oldType, user.user_id]);
        }
        return sendJson(res, {ok:true});
      }

      /** 删除分类：分类下已有记账记录时禁止删除（409） */
      if (method === "DELETE") {
        var cr = await pool.query("SELECT * FROM categories WHERE id=? AND user_id=?", [cid, user.user_id]);
        if (cr[0].length === 0) return sendJson(res, {error:"\u5206\u7c7b\u672a\u627e\u5230"}, 404);
        var used = await pool.query("SELECT COUNT(*) as c FROM transactions WHERE category=? AND user_id=?", [cr[0][0].name, user.user_id]);
        if (used[0][0].c > 0) return sendJson(res, {error:"\u8be5\u5206\u7c7b\u4e0b\u5df2\u6709\u8bb0\u5f55\uff0c\u65e0\u6cd5\u5220\u9664"}, 409);
        await pool.query("DELETE FROM categories WHERE id=? AND user_id=?", [cid, user.user_id]);
        return sendJson(res, {ok:true});
      }
    }

    /** 非接口路径：交给静态文件服务（页面/样式/脚本） */
    serveStatic(res, pn);
  } catch(e) {
    /** 统一错误处理：任何未捕获异常返回 500，并在控制台打印详情 */
    console.error(e);
    sendJson(res, {error:"\u670d\u52a1\u5668\u5185\u90e8\u9519\u8bef"}, 500);
  }
}

/** 启动流程：先初始化数据库，再启动 HTTP 服务器；MySQL 连接失败时给出提示并退出 */
initDB().then(function() {
  http.createServer(handleRequest).listen(PORT, function() {
    console.log("http://localhost:" + PORT);
  });
}).catch(function(e) {
  console.error("MySQL connection failed:", e.message);
  console.log("");console.log("To fix: set your MySQL root password and try again:");console.log("  set DB_PASSWORD=YOUR_MYSQL_ROOT_PASSWORD");console.log("  node server.js");console.log("");
  process.exit(1);
});
