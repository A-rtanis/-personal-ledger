/**
 * ============================================================
 * 记账本 - 前端逻辑文件 (app.js)
 * ------------------------------------------------------------
 * 功能概述：
 *   1. 用户注册 / 登录 / 退出（每次访问需重新登录，记住上次用户名）
 *   2. 记账记录的增删改查、状态切换
 *   3. 月度收支统计（收入 / 支出 / 结余）
 *   4. 支出柱状图（近 7 / 15 / 30 天）
 *   5. 分类管理（新增 / 编辑 / 删除）
 * 所有数据请求通过统一的 api() 函数发送，并携带登录令牌（token）。
 * ============================================================
 */

/** API 基础路径：所有后端接口都以 /api 开头 */
const API = '/api';

/** 登录令牌：从浏览器本地存储读取（每次访问页面都会在 initAuth 中清空，强制重新登录） */
var token = localStorage.getItem('token') || '';

/** 页面加载时的当前日期时间（用于默认日期、自动判断状态） */
const today = new Date();
/** 当前年份（用于筛选下拉框默认选中项） */
const curYear = today.getFullYear();
/** 当前月份（补零为两位，如 "08"，用于筛选下拉框默认选中项） */
const curMonth = String(today.getMonth() + 1).padStart(2, '0');

/**
 * 获取页面元素
 * @param {string} id 元素 id
 * @returns {HTMLElement} 对应的 DOM 元素
 */
function $(id) { return document.getElementById(id); }

/**
 * 按 CSS 选择器批量获取元素（返回 NodeList）
 * @param {string} sel CSS 选择器
 * @returns {NodeList} 匹配的元素列表
 */
function qsa(sel) { return document.querySelectorAll(sel); }

/**
 * 金额格式化：加上人民币符号并保留两位小数（如 ¥1,234.50）
 * @param {number} n 金额数值
 * @returns {string} 格式化后的金额字符串
 */
function fmt(n) { return '\u00a5' + Number(n).toLocaleString('zh-CN', {minimumFractionDigits:2, maximumFractionDigits:2}); }

/**
 * 将日期对象格式化为 "YYYY-MM-DD" 字符串（按本地时间，避免 UTC 时区差一天）
 * @param {Date} d 日期对象
 * @returns {string} 格式化日期字符串
 */
function localDateStr(d) {
  var y = d.getFullYear(), m = d.getMonth() + 1, dd = d.getDate();
  return y + '-' + (m < 10 ? '0' + m : m) + '-' + (dd < 10 ? '0' + dd : dd);
}

/**
 * HTML 转义：防止用户输入的内容（备注、分类名等）被当作 HTML 执行（XSS 防护）
 * @param {*} s 原始内容
 * @returns {string} 转义后的安全字符串
 */
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function(ch) {
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch];
  });
}

/**
 * 统一的后端请求函数：负责拼接地址、附加登录令牌、处理错误
 * @param {string} method HTTP 方法（GET / POST / PUT / DELETE）
 * @param {string} path 接口路径（无需带 /api，会自动拼接）
 * @param {object} [body] 请求体（对象，会自动转 JSON）
 * @returns {Promise<object>} 后端返回的 JSON 数据
 */
async function api(method, path, body) {
  /** 记录本次请求发起时的令牌，用于判断登录状态是否已变化（防止旧校验结果误清新令牌） */
  const usedToken = token;
  const opts = { method, headers: {'Content-Type':'application/json'} };
  if (usedToken) opts.headers['Authorization'] = 'Bearer ' + usedToken;
  if (body) opts.body = JSON.stringify(body);
  const r = await fetch(API + path, opts);
  if (!r.ok) {
    /** 优先显示后端返回的错误信息，否则显示状态码 */
    let msg = '\u8bf7\u6c42\u5931\u8d25 (' + r.status + ')';
    try { const e = await r.json(); if (e && e.error) msg = e.error; } catch (_) {}
    /** 登录已失效（401）且令牌未变化时：清除令牌并回到登录页 */
    if (r.status === 401 && path !== '/login' && path !== '/register' && usedToken === token) {
      localStorage.removeItem('token'); token = '';
      showAuth();
    }
    throw new Error(msg);
  }
  return r.json();
}

// ============================================================
// 登录 / 注册 / 退出 模块
// ============================================================

/**
 * 显示登录/注册界面（隐藏主应用）
 */
function showAuth() {
  $('auth-screen').style.display = 'flex';
  $('app').style.display = 'none';
}

/**
 * 显示主应用界面（隐藏登录界面），并加载当月记账数据
 * @param {string} username 当前登录的用户名（显示在页面右上角）
 */
function showApp(username) {
  $('auth-screen').style.display = 'none';
  $('app').style.display = 'block';
  if (username) $('current-user').textContent = username;
  loadRecords();
}

/**
 * 切换登录面板与注册面板
 * @param {boolean} showLogin true 显示登录面板，false 显示注册面板
 */
function switchPanel(showLogin) {
  $('login-panel').style.display = showLogin ? 'block' : 'none';
  $('register-panel').style.display = showLogin ? 'none' : 'block';
}

/** 点击「去注册」链接：切换到注册面板 */
$('link-to-register').addEventListener('click', function() { switchPanel(false); });
/** 点击「去登录」链接：切换到登录面板 */
$('link-to-login').addEventListener('click', function() { switchPanel(true); });

/**
 * 登录表单提交：校验输入 -> 调用登录接口 -> 保存令牌并进入应用
 */
$('login-form').addEventListener('submit', async function(e) {
  e.preventDefault();
  var u = $('login-username').value.trim(), p = $('login-password').value;
  if (!u || !p) { alert('\u8bf7\u8f93\u5165\u7528\u6237\u540d\u548c\u5bc6\u7801'); return; }
  try {
    var res = await api('POST', '/login', { username: u, password: p });
    if (!res.token) { alert('\u767b\u5f55\u5931\u8d25\uff1a\u672a\u8fd4\u56de\u4f1a\u8bdd\u6807\u8bc6'); return; }
    token = res.token; localStorage.setItem('token', token);
    /** 记住本次登录的用户名，下次打开登录页自动填入 */
    localStorage.setItem('lastUser', u);
    showApp(res.username);
  } catch (err) { alert(err.message); }
});

/**
 * 注册表单提交：校验用户名(2-8字符)、密码(6-18位)、两次密码一致 -> 调用注册接口 -> 自动登录进入应用
 */
$('register-form').addEventListener('submit', async function(e) {
  e.preventDefault();
  var u = $('reg-username').value.trim();
  var p = $('reg-password').value, p2 = $('reg-password2').value;
  if (u.length < 2 || u.length > 8) { alert('\u7528\u6237\u540d\u957f\u5ea6\u9700\u4e3a2-8\u4e2a\u5b57\u7b26'); return; }
  if (p.length < 6 || p.length > 18) { alert('\u5bc6\u7801\u957f\u5ea6\u9700\u4e3a6-18\u4f4d'); return; }
  if (p !== p2) { alert('\u4e24\u6b21\u8f93\u5165\u7684\u5bc6\u7801\u4e0d\u4e00\u81f4'); return; }
  try {
    var res = await api('POST', '/register', { username: u, password: p });
    if (!res.token) { alert('\u6ce8\u518c\u5931\u8d25\uff1a\u672a\u8fd4\u56de\u4f1a\u8bdd\u6807\u8bc6'); return; }
    token = res.token; localStorage.setItem('token', token);
    /** 记住本次注册的用户名，下次打开登录页自动填入 */
    localStorage.setItem('lastUser', u);
    showApp(res.username);
  } catch (err) { alert(err.message); }
});

/**
 * 退出登录：通知服务器删除会话 -> 清除本地令牌 -> 回到登录页（并保留上次用户名）
 */
$('btn-logout').addEventListener('click', async function() {
  try { await api('POST', '/logout'); } catch (e) {}
  localStorage.removeItem('token'); token = '';
  $('login-username').value = localStorage.getItem('lastUser') || '';
  showAuth();
});

/**
 * 页面初始化：每次访问都清除令牌（强制重新登录），并预填上次登录的用户名
 */
function initAuth() {
  localStorage.removeItem('token');
  token = '';
  $('login-username').value = localStorage.getItem('lastUser') || '';
  showAuth();
}

// ============================================================
// 年份 / 月份下拉框初始化
// ============================================================

/**
 * 向下拉框填充年份选项（1960-2100），默认选中当前年份
 * @param {HTMLSelectElement} sel 年份下拉框
 */
function populateYears(sel) {
  sel.innerHTML = '';
  for (let y = 1960; y <= 2100; y++) {
    const o = document.createElement('option');
    o.value = String(y);
    o.textContent = y + '\u5e74';
    if (y === curYear) o.selected = true;
    sel.appendChild(o);
  }
}

/** 初始化记账页与统计页的年份下拉框 */
populateYears($('filter-year'));
populateYears($('stats-year'));
/** 初始化记账页与统计页的月份下拉框 */
populateMonths($('filter-month'));
populateMonths($('stats-month'));

/**
 * 向下拉框填充月份选项（1-12 月），默认选中当前月份
 * @param {HTMLSelectElement} sel 月份下拉框
 */
function populateMonths(sel) {
  for (var i = 1; i <= 12; i++) {
    var v = i < 10 ? '0' + i : '' + i;
    var o = document.createElement('option');
    o.value = v;
    o.textContent = i + '\u6708';
    if (v === curMonth) o.selected = true;
    sel.appendChild(o);
  }
}

/** 默认选中当前月份 */
$('filter-month').value = curMonth;
$('stats-month').value = curMonth;

// ============================================================
// 顶部标签页切换（记账 / 统计 / 分类）
// ============================================================

/** 为每个标签按钮绑定点击事件：切换激活状态，并按标签加载对应数据 */
qsa('.tab').forEach(function(btn) {
  btn.addEventListener('click', function() {
    qsa('.tab').forEach(function(b) { b.classList.remove('active'); });
    qsa('.tab-content').forEach(function(c) { c.classList.remove('active'); });
    btn.classList.add('active');
    $('tab-' + btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'stats') loadStats();
    if (btn.dataset.tab === 'categories') loadCategories();
  });
});

// ============================================================
// 记账记录：加载、渲染、增删改查
// ============================================================

/**
 * 加载当前筛选年月下的记账记录与收支统计，并渲染到页面
 */
async function loadRecords() {
  try {
    const year = $('filter-year').value;
    const month = $('filter-month').value;
    const a = api('GET', '/transactions?year=' + year + '&month=' + month);
    const b = api('GET', '/transactions/stats?year=' + year + '&month=' + month);
    const [records, stats] = await Promise.all([a, b]);
    renderRecords(records);
    $('stat-income').textContent = fmt(stats.income);
    $('stat-expense').textContent = fmt(stats.expense);
    $('stat-balance').textContent = fmt(stats.balance);
  } catch (err) { alert(err.message); }
}

/**
 * 将记录数组渲染成表格行，并绑定每行的编辑 / 删除 / 状态切换按钮事件
 * @param {Array} records 记账记录数组
 */
function renderRecords(records) {
  const tbody = $('records-body');
  const empty = $('empty-msg');
  tbody.innerHTML = '';
  if (records.length === 0) { empty.style.display = 'block'; return; }
  empty.style.display = 'none';
  records.forEach(function(r) {
    const tr = document.createElement('tr');
    /** 类型中文显示：收入 / 支出 */
    var tl = r.type === 'income' ? '\u6536\u5165' : '\u652f\u51fa';
    /** 状态中文显示：已完成 / 未完成 */
    var s = r.status === 'done' ? '\u5df2\u5b8c\u6210' : '\u672a\u5b8c\u6210';
    /** 操作按钮：编辑 / 删除 / 切换状态（按钮文案随状态变化） */
    var btns = '<button class="btn small btn-edit" data-id="' + r.id + '">\u7f16\u8f91</button> ';
    btns += '<button class="btn small btn-del" data-id="' + r.id + '">\u5220\u9664</button> ';
    btns += '<button class="btn small btn-toggle" data-id="' + r.id + '">';
    btns += (r.status === 'done' ? '\u6807\u672a\u5b8c\u6210' : '\u6807\u5df2\u5b8c\u6210') + '</button>';
    /** 拼装表格行（用户输入内容经 esc 转义，防止 XSS） */
    tr.innerHTML = '<td>' + esc(r.date) + '</td><td class="type-' + r.type + '">' + tl + '</td>';
    tr.innerHTML += '<td>' + (esc(r.category) || '-') + '</td>';
    tr.innerHTML += '<td class="type-' + r.type + '" style="font-weight:600">' + fmt(r.amount) + '</td>';
    tr.innerHTML += '<td>' + (esc(r.note) || '-') + '</td>';
    tr.innerHTML += '<td><span class="status-' + r.status + '">' + s + '</span></td>';
    tr.innerHTML += '<td>' + btns + '</td>';
    /** 绑定三个操作按钮的点击事件 */
    tr.querySelector('.btn-edit').addEventListener('click', function() { openEdit(r); });
    tr.querySelector('.btn-del').addEventListener('click', function() { deleteRecord(r.id); });
    tr.querySelector('.btn-toggle').addEventListener('click', function() { toggleStatus(r); });
    tbody.appendChild(tr);
  });
}

/** 切换筛选年份时重新加载记录 */
$('filter-year').addEventListener('change', loadRecords);
/** 切换筛选月份时重新加载记录 */
$('filter-month').addEventListener('change', loadRecords);

/**
 * 为新增/编辑记录弹窗的分类下拉框填充数据（按当前所选类型过滤），并支持回填选中项
 * @param {string} [selected] 编辑时需要回填选中的分类名
 */
async function loadCategoriesForForm(selected) {
  try {
    const cats = await api('GET', '/categories');
    const sel = $('form-category');
    const type = $('form-type').value;
    sel.innerHTML = '';
    /** 优先显示当前类型的分类；若该类型一个分类都没有（例如全被删掉），则回退显示全部分类，保证表单可以提交 */
    let list = cats.filter(function(c) { return c.type === type; });
    if (list.length === 0) list = cats;
    list.forEach(function(c) {
      const o = document.createElement('option');
      o.value = c.name; o.textContent = c.name; sel.appendChild(o);
    });
    /** 编辑时若原分类不在下拉列表里（例如切换过类型），补一个选项防止保存时被静默改掉 */
    if (selected && !list.some(function(c) { return c.name === selected; })) {
      const o = document.createElement('option');
      o.value = selected; o.textContent = selected; sel.appendChild(o);
    }
    sel.value = selected || (list.length > 0 ? list[0].name : '');
  } catch (err) { alert(err.message); }
}

/** 切换记录类型（收入/支出）时刷新分类下拉框 */
$('form-type').addEventListener('change', function() { loadCategoriesForForm(); });

/**
 * 打开新增/编辑记录弹窗
 * @param {string} title 弹窗标题
 * @param {object} [record] 有值表示编辑（回填数据），无值表示新增（空表单 + 默认当天日期）
 */
function openModal(title, record) {
  $('modal-title').textContent = title;
  $('modal').style.display = 'flex';
  if (record) {
    $('form-id').value = record.id; $('form-date').value = record.date;
    $('form-type').value = record.type; $('form-amount').value = record.amount;
    $('form-status').value = record.status; $('form-note').value = record.note || '';
  } else {
    $('form-id').value = ''; $('form-date').value = localDateStr(today);
    $('form-type').value = 'expense'; $('form-amount').value = '';
    $('form-note').value = '';
  }
  /** 加载分类下拉框，编辑时回填原分类，避免保存后被静默改错 */
  loadCategoriesForForm(record ? record.category : null);
  /** 新增时按日期自动判断状态：今天及以前=已完成，未来=未完成 */
  if (!$('form-id').value) {
    $('form-status').value = $('form-date').value <= localDateStr(today) ? 'done' : 'pending';
  }
}

/** 关闭记录弹窗 */
function closeModal() { $('modal').style.display = 'none'; }

/** 点击「+ 新增记录」打开新增弹窗 */
$('btn-add').addEventListener('click', function() { openModal('\u65b0\u589e\u8bb0\u5f55'); });
/** 点击弹窗「取消」关闭 */
$('modal-cancel').addEventListener('click', closeModal);
/** 修改日期时重新自动判断状态 */
$('form-date').addEventListener('change', function() {
  $('form-status').value = $('form-date').value <= localDateStr(today) ? 'done' : 'pending';
});
/** 点击弹窗遮罩空白处关闭 */
$('modal').addEventListener('click', function(e) { if (e.target === $('modal')) closeModal(); });

/**
 * 记录弹窗表单提交：新增（POST）或编辑（PUT），成功后刷新列表
 */
$('modal-form').addEventListener('submit', async function(e) {
  e.preventDefault();
  var body = { date: $('form-date').value, type: $('form-type').value,
    category: $('form-category').value, amount: parseFloat($('form-amount').value),
    status: $('form-status').value, note: $('form-note').value };
  try {
    var id = $('form-id').value;
    if (id) { await api('PUT', '/transactions/' + id, body); }
    else { await api('POST', '/transactions', body); }
    closeModal(); loadRecords();
  } catch (err) { alert(err.message); }
});

/** 打开编辑弹窗（标题为「编辑记录」） */
function openEdit(r) { openModal('\u7f16\u8f91\u8bb0\u5f55', r); }

/**
 * 删除记录：二次确认后调用删除接口，成功后刷新列表
 * @param {number} id 记录 id
 */
async function deleteRecord(id) {
  if (!confirm('\u786e\u5b9a\u5220\u9664\u8fd9\u6761\u8bb0\u5f55\uff1f')) return;
  try { await api('DELETE', '/transactions/' + id); loadRecords(); }
  catch (err) { alert(err.message); }
}

/**
 * 切换记录状态（已完成 <-> 未完成）
 * @param {object} r 记录对象
 */
async function toggleStatus(r) {
  try {
    await api('PUT', '/transactions/' + r.id, { status: r.status === 'done' ? 'pending' : 'done' });
    loadRecords();
  } catch (err) { alert(err.message); }
}

// ============================================================
// 统计模块：月度收支统计 + 支出柱状图
// ============================================================

/**
 * 加载统计页的月度收支数据，并绘制支出柱状图
 */
async function loadStats() {
  try {
    var year = $('stats-year').value, month = $('stats-month').value;
    var stats = await api('GET', '/transactions/stats?year=' + year + '&month=' + month);
    $('stats-income').textContent = fmt(stats.income);
    $('stats-expense').textContent = fmt(stats.expense);
    $('stats-balance').textContent = fmt(stats.balance);
    await drawChart(chartDays);
  } catch (err) { alert(err.message); }
}

/** 统计页切换月份时重新加载 */
$('stats-month').addEventListener('change', loadStats);
/** 统计页切换年份时重新加载 */
$('stats-year').addEventListener('change', loadStats);

/** 柱状图当前天数（默认近 7 天） */
var chartDays = 7;

/** 图表天数按钮（近7/15/30天）：点击切换并重绘图表 */
qsa('.chart-btn').forEach(function(btn) {
  btn.addEventListener('click', function() {
    qsa('.chart-btn').forEach(function(b) { b.classList.remove('active'); });
    btn.classList.add('active');
    chartDays = parseInt(btn.dataset.days);
    drawChart(chartDays).catch(function(err) { alert(err.message); });
  });
});

/**
 * 用 Canvas 绘制近 N 天支出柱状图（数据来自后端 /transactions/expenses）
 * @param {number} days 显示最近多少天
 */
async function drawChart(days) {
  var data = await api('GET', '/transactions/expenses?days=' + days);
  var canvas = $('expense-chart');
  var ctx = canvas.getContext('2d');
  /** 根据父容器宽度自适应画布（考虑高清屏 devicePixelRatio） */
  var rect = canvas.parentElement.getBoundingClientRect();
  var w = (rect.width - 32) || 600;
  var h = 250;
  canvas.width = Math.min(w, 900) * (window.devicePixelRatio || 1);
  canvas.height = h * (window.devicePixelRatio || 1);
  ctx.scale(window.devicePixelRatio || 1, window.devicePixelRatio || 1);
  ctx.clearRect(0, 0, w, h);
  /** 左上角显示数据日期范围 */
  if (data.length > 0) {
    var f = data[0].date;
    var l = data[data.length - 1].date;
    ctx.fillStyle = '#999';
    ctx.font = '12px sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(f + ' ~ ' + l, w - 10, 14);
  }
  /** 最大金额用于按比例计算柱高（避免除零，最小为 1） */
  var maxVal = Math.max.apply(null, data.map(function(d) { return d.amount; })) || 1;
  /** 绘图区四周留白 */
  var pad = { top: 24, bottom: 30, left: 10, right: 10 };
  var cw = w - pad.left - pad.right;
  var ch = h - pad.top - pad.bottom;
  /** 每根柱子的间距与宽度（天数多时柱宽收窄） */
  var gap = data.length > 0 ? cw / data.length : 0;
  var bw = Math.min(gap * 0.6, days > 15 ? 10 : 30);
  /** 天数多时字体变小 */
  var fs = days > 20 ? '8px' : '10px';
  data.forEach(function(d, i) {
    /** 柱子位置与高度（金额为 0 时不画柱体，只画日期） */
    var x = pad.left + i * gap + (gap - bw) / 2;
    var bh = (d.amount / maxVal) * ch;
    var y = pad.top + ch - bh;
    if (d.amount > 0) {
      /** 红色渐变填充柱体（兼容不支持 roundRect 的老浏览器） */
      var g = ctx.createLinearGradient(x, y, x, pad.top + ch);
      g.addColorStop(0, '#e74c3c');
      g.addColorStop(1, '#f1948a');
      ctx.fillStyle = g;
      ctx.beginPath();
      if (ctx.roundRect) { ctx.roundRect(x, y, bw, bh, [3, 3, 0, 0]); }
      else { ctx.rect(x, y, bw, bh); }
      ctx.fill();
    }
    /** 柱底画日期（取 "MM-DD" 的日号） */
    ctx.fillStyle = '#888';
    ctx.font = fs + ' sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(String(d.date).slice(8), x + bw / 2, h - pad.bottom + 16);
    /** 柱顶画金额 */
    if (d.amount > 0) {
      ctx.fillStyle = '#333';
      ctx.font = 'bold ' + fs + ' sans-serif';
      ctx.fillText(fmt(d.amount), x + bw / 2, y - 4);
    }
  });
}

// ============================================================
// 分类管理模块：列表渲染、新增、编辑、删除
// ============================================================

/**
 * 加载并渲染分类列表（"其他收入/其他支出" 只读，不显示编辑/删除按钮）
 */
async function loadCategories() {
  try {
    var cats = await api('GET', '/categories');
    var list = $('category-list'); list.innerHTML = '';
    cats.forEach(function(c) {
      var div = document.createElement('div'); div.className = 'cat-item';

      /** 类型中文显示：收入 / 支出 */
      var tl = c.type === 'income' ? '\u6536\u5165' : '\u652f\u51fa';
      var showType = '<span class="cat-type ' + c.type + '">' + tl + '</span>';
      /** 分类名称（转义后显示，防 XSS） */
      div.innerHTML = '<div><span class="cat-name">' + esc(c.name) + '</span>' + showType + '</div>';
      /** 名称以「其他」开头的默认分类不可编辑/删除，不显示操作按钮 */
      var isOther = c.name.indexOf('\u5176\u4ed6') === 0;
      if (!isOther) {
        div.innerHTML += '<div class="cat-actions"><button class="btn small cat-edit" data-id="' + c.id + '">\u7f16\u8f91</button> <button class="btn small danger cat-del" data-id="' + c.id + '">\u5220\u9664</button></div>';
      }
      /** 绑定编辑、删除按钮事件 */
      var editEl = div.querySelector('.cat-edit');
      if (editEl) editEl.addEventListener('click', function() { openCatEdit(c); });
      var delEl = div.querySelector('.cat-del');
      if (delEl) delEl.addEventListener('click', function() { deleteCategory(c.id); });
      list.appendChild(div);
    });
  } catch (err) { alert(err.message); }
}

/**
 * 打开新增/编辑分类弹窗
 * @param {string} title 弹窗标题
 * @param {object} [cat] 有值表示编辑（回填数据），无值表示新增
 */
function openCatModal(title, cat) {
  $('cat-modal-title').textContent = title; $('cat-modal').style.display = 'flex';
  if (cat) {
    $('cat-form-id').value = cat.id; $('cat-form-name').value = cat.name; $('cat-form-type').value = cat.type;
  } else {
    $('cat-form-id').value = ''; $('cat-form-name').value = ''; $('cat-form-type').value = 'expense';
  }
}

/** 关闭分类弹窗 */
function closeCatModal() { $('cat-modal').style.display = 'none'; }

/** 点击「+ 新增分类」打开新增弹窗 */
$('btn-add-cat').addEventListener('click', function() { openCatModal('\u65b0\u589e\u5206\u7c7b'); });
/** 点击分类弹窗「取消」关闭 */
$('cat-modal-cancel').addEventListener('click', closeCatModal);
/** 点击分类弹窗遮罩空白处关闭 */
$('cat-modal').addEventListener('click', function(e) { if (e.target === $('cat-modal')) closeCatModal(); });

/**
 * 分类弹窗表单提交：新增（POST）或编辑（PUT），成功后刷新分类列表
 */
$('cat-modal-form').addEventListener('submit', async function(e) {
  e.preventDefault();
  var id = $('cat-form-id').value;
  var body = { name: $('cat-form-name').value, type: $('cat-form-type').value };
  try {
    if (id) { await api('PUT', '/categories/' + id, body); }
    else { await api('POST', '/categories', body); }
    closeCatModal(); loadCategories();
  } catch (err) { alert(err.message); }
});

/** 打开分类编辑弹窗（标题为「编辑分类」） */
function openCatEdit(c) { openCatModal('\u7f16\u8f91\u5206\u7c7b', c); }

/**
 * 删除分类：二次确认后调用删除接口（后端会拒绝删除仍有记录的分类），成功后刷新列表
 * @param {number} id 分类 id
 */
async function deleteCategory(id) {
  if (!confirm('\u786e\u5b9a\u5220\u9664\u6b64\u5206\u7c7b\uff1f\u5982\u679c\u5206\u7c7b\u4e0b\u6709\u8bb0\u5f55\u5219\u65e0\u6cd5\u5220\u9664\u3002')) return;
  try { await api('DELETE', '/categories/' + id); loadCategories(); }
  catch (err) { alert(err.message); }
}

/** 页面启动：执行初始化（每次访问都要求登录） */
initAuth();
