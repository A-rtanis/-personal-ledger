@echo off
chcp 65001 >nul
title 记账软件启动器
echo ====================================
echo   记账软件 - App (MySQL)
echo ====================================
echo.

rem 检查 Node.js 是否安装
where node >nul 2>nul
if errorlevel 1 (
    echo [错误] 未找到 Node.js，请先安装: https://nodejs.org/
    pause
    exit /b 1
)

rem 检查端口 8080 是否已被占用（软件可能已在运行）
netstat -ano | findstr ":8080 " | findstr "LISTENING" >nul 2>nul
if not errorlevel 1 (
    echo 软件似乎已经在运行了。
    echo 请直接打开浏览器访问: http://localhost:8080
    echo 如果打不开，请先关闭正在运行的 node.exe 进程再试。
    pause
    exit /b 0
)

echo 数据库名: app（首次启动会自动创建）
echo.
set /p _dbpw=请输入 MySQL root 密码（没有则直接回车）:
if not "%_dbpw%"=="" set "DB_PASSWORD=%_dbpw%"

echo 正在启动，请稍候...
node server.js
if errorlevel 1 (
    echo.
    echo 启动失败，常见原因:
    echo   1. MySQL 服务未启动，或 root 密码输入错误（请重试）
    echo   2. 也可以在命令行先执行: set DB_PASSWORD=你的密码
    echo   3. 若提示端口被占用，请先关闭正在运行的 node.exe
    pause
)
