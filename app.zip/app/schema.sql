-- 创建数据库
CREATE DATABASE IF NOT EXISTS app CHARACTER SET utf8mb4;
USE app;

-- 用户表
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(8) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 会话表
CREATE TABLE IF NOT EXISTS sessions (
  token VARCHAR(64) PRIMARY KEY,
  user_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 分类表（user_id 区分所属用户）
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  type ENUM('income', 'expense') NOT NULL,
  is_default TINYINT(1) DEFAULT 0,
  user_id INT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 交易记录表（user_id 区分所属用户）
CREATE TABLE IF NOT EXISTS transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  date DATE NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  category VARCHAR(50) NOT NULL,
  type ENUM('income', 'expense') NOT NULL,
  note TEXT,
  status ENUM('pending', 'done') DEFAULT 'done',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  user_id INT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 注意：默认分类由服务端在用户注册时自动为该用户插入，
-- 无需手动执行下面的语句（仅作参考）。
-- INSERT INTO categories (name, type, is_default) VALUES
-- ('餐饮', 'expense', 1), ...
