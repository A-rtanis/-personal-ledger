# Finance App - MySQL Edition

A full-stack personal finance tracking application with MySQL database.

## Tech Stack
- **Frontend**: HTML + CSS + JavaScript (Vanilla JS)
- **Backend**: Node.js (HTTP server, no framework)
- **Database**: MySQL with mysql2 driver

## Prerequisites
- Node.js (v16+) - [Download](https://nodejs.org/)
- MySQL (5.7+) - [Download](https://dev.mysql.com/downloads/)

## Setup

### 1. Install MySQL
Install MySQL and start the service. Remember your root password.

### 2. Install dependencies
```
npm install
```

### 3. Configure database connection (optional)
By default, it connects with:
```
Host: localhost
Port: 3306
User: root
Password: (empty)
Database: app
```
To override, set environment variables:
```
set DB_USER=root
set DB_PASSWORD=yourpassword
```

### 4. Start the app
```
npm start
```
or
```
node server.js
```

### 5. Open browser
Visit: http://localhost:8080

## Features
- User register/login (username 2-8 chars, password 6-18 chars; scrypt-hashed passwords)
- Per-user data isolation (each account sees only its own transactions and categories)
- Add/edit/delete transactions with date, amount, category, notes
- Income/Expense classification with customizable categories
- Monthly statistics (income, expense, balance)
- Bar chart for last 7/15/30 days
- Category management (add/edit/delete; categories in use cannot be deleted; 其他* default categories are read-only)
- Status tracking (pending/done)
- Future dates auto-set to pending, past dates auto-set to done

## Database
Database and tables are created automatically on first run.
Default categories are inserted automatically when a user registers (per user).
The first registered user adopts any pre-existing (pre-login) local data.
To reset completely: drop the `app` database and restart.

## File Structure
```
app/
├── server.js         -- Backend (HTTP API + MySQL)
├── schema.sql        -- Database schema (reference only)
├── package.json      -- Dependencies
├── index.html        -- Frontend page
├── styles.css        -- Styles
├── app.js            -- Frontend logic
└── README.md         -- This file
```
